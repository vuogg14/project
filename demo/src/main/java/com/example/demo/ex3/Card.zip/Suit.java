package HW_2.ex3;

public enum Suit {
    HEART, DIAMOND, CLUB, SPADES;
}
