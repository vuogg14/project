module com.example.demo {
    requires javafx.controls;
    requires javafx.fxml;


    opens Hw2_22001666_LeMinhVuong.ex1 to javafx.fxml;
    exports Hw2_22001666_LeMinhVuong.ex1;

}