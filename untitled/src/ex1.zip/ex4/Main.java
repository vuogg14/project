package ex4;

public class Main {
    public static void main(String[] args) {
        Sphere sphere1 = new Sphere(5.0, 0, 0, 0);
        Sphere sphere2 = new Sphere( 4.0, 8, 0, 0);

        System.out.println(sphere1);
        System.out.println(sphere2);
        sphere1.check(sphere2);


//        if (sphere1.isInside(sphere2)) {
//            System.out.println("Hình cầu 1 nằm bên trong hình cầu 2.");
//        } else if (sphere2.isInside(sphere1)) {
//            System.out.println("Hình cầu 2 nằm bên trong hình cầu 1.");
//        } else {
//            System.out.println("Hai hình cầu không bao nhau.");
//        }
//
//
//        if (sphere1.isIntersect(sphere2)) {
//            System.out.println("Hình cầu 1 và hình cầu 2 giao nhau.");
//        } else {
//            System.out.println("Hai hình cầu không giao nhau.");
//        }
    }
}
